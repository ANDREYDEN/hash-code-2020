class Book:
    def __init__(self, id, score):
        self.id = id
        self.score = score
